package com.santoos30.spotifyapi2bi

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase
import model.Atividade
import java.util.UUID

class FazerAtvActivity : AppCompatActivity() {

    private lateinit var database: FirebaseDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fzr_atv)
        database = FirebaseDatabase.getInstance()

        val editTitulo     = findViewById<EditText>(R.id.TituloAtv)
        val editTipo       = findViewById<EditText>(R.id.TipoAtv)
        val editDificuldade = findViewById<EditText>(R.id.DifAtv)
        val editResposta   = findViewById<EditText>(R.id.RespostaAtv)
        val btnSalvar      = findViewById<Button>(R.id.CriarAtv)
        val btnVoltar      = findViewById<Button>(R.id.btnVoltar)

        btnVoltar.setOnClickListener { finish() }

        btnSalvar.setOnClickListener {
            val titulo     = editTitulo.text.toString().trim()
            val tipo       = editTipo.text.toString().trim()
            val dificuldade = editDificuldade.text.toString().trim()
            val resposta   = editResposta.text.toString().trim()

            if (titulo.isEmpty() || tipo.isEmpty() || resposta.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val id = UUID.randomUUID().toString()
            val atividade = Atividade(
                id = id,
                titulo = titulo,
                tipo = tipo,
                dificuldade = dificuldade,
                respostaCorreta = resposta
            )
            database.getReference("atividades").child(id).setValue(atividade)
            Toast.makeText(this, "Atividade salva!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}